---
name: AgroModern
colors:
  surface: '#f3faff'
  surface-dim: '#c7dde9'
  surface-bright: '#f3faff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#e6f6ff'
  surface-container: '#dbf1fe'
  surface-container-high: '#d5ecf8'
  surface-container-highest: '#cfe6f2'
  on-surface: '#071e27'
  on-surface-variant: '#40493d'
  inverse-surface: '#1e333c'
  inverse-on-surface: '#dff4ff'
  outline: '#707a6c'
  outline-variant: '#bfcaba'
  surface-tint: '#1b6d24'
  primary: '#0d631b'
  on-primary: '#ffffff'
  primary-container: '#2e7d32'
  on-primary-container: '#cbffc2'
  inverse-primary: '#88d982'
  secondary: '#875200'
  on-secondary: '#ffffff'
  secondary-container: '#f89c00'
  on-secondary-container: '#623a00'
  tertiary: '#1f6223'
  on-tertiary: '#ffffff'
  tertiary-container: '#3a7b39'
  on-tertiary-container: '#c8ffbf'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#a3f69c'
  primary-fixed-dim: '#88d982'
  on-primary-fixed: '#002204'
  on-primary-fixed-variant: '#005312'
  secondary-fixed: '#ffddba'
  secondary-fixed-dim: '#ffb865'
  on-secondary-fixed: '#2b1700'
  on-secondary-fixed-variant: '#663d00'
  tertiary-fixed: '#acf4a4'
  tertiary-fixed-dim: '#91d78a'
  on-tertiary-fixed: '#002203'
  on-tertiary-fixed-variant: '#0c5216'
  background: '#f3faff'
  on-background: '#071e27'
  surface-variant: '#cfe6f2'
typography:
  headline-lg:
    fontFamily: Manrope
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Manrope
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Manrope
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Manrope
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Manrope
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-lg:
    fontFamily: Manrope
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
  label-sm:
    fontFamily: Manrope
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 32px
  gutter: 16px
  margin: 16px
---

## Brand & Style

This design system is built to bridge the gap between traditional agricultural commerce and high-speed modern marketplaces. The brand personality is rooted in reliability and growth, utilizing a "Corporate Modern" style that prioritizes clarity and functional aesthetics over decorative flair.

The UI evokes a sense of freshness and professionalism, designed to foster trust between individual sellers and buyers. By blending the utility of a peer-to-peer marketplace with the slick, efficient interface of a delivery service, the design system ensures that high-volume product listings remain easy to navigate and aesthetically pleasing.

## Colors

The palette is anchored by a deep agricultural green that signifies vitality and stability. This primary color is used for key actions and brand presence. A secondary harvest-inspired amber is used sparingly for highlights, notifications, or "Fresh" badges to provide visual warmth.

The background uses a soft off-white to reduce eye strain and provide a clean canvas for colorful produce photography. Neutrals are balanced towards cool slates to maintain a professional, tech-forward tone, ensuring text hierarchy is sharp and legible.

## Typography

This design system utilizes a single, highly versatile sans-serif family to ensure maximum legibility across diverse user demographics. The typeface is chosen for its balanced proportions and modern geometric construction.

Headlines use tighter letter spacing and heavier weights to create a sense of authority and clear section breaks. Body text is optimized for readability with generous line heights, ensuring that product descriptions and pricing information are easily digestible at a glance.

## Layout & Spacing

A strict 8dp grid governs the entire spatial system, ensuring mathematical harmony and predictability across all screens. All components, margins, and padding must be multiples of 8px to maintain vertical and horizontal rhythm.

The layout follows a fluid grid model with a 16px gutter. On mobile devices, a 16px side margin is the standard, while tablet and desktop views may expand margins to contain content within a readable max-width. Elements should snap to the grid to reinforce the professional and systematic nature of the marketplace.

## Elevation & Depth

Visual hierarchy is established through a combination of tonal layering and soft ambient shadows. Surfaces that require user interaction sit on a slightly elevated plane, indicated by diffused, low-opacity shadows (Blur 8px-16px, Opacity 4-8%) rather than harsh outlines.

The background remains flat, while cards and interactive containers use a subtle white surface to pop against the off-white background. This "stacking" approach creates a clear mental model of the interface, where the most important transactional elements appear closest to the user.

## Shapes

The shape language is defined by soft, approachable geometry. Standard UI elements like buttons and input fields utilize a 12px corner radius. Larger containers, such as product cards and modals, utilize a 16px radius to appear friendlier and more modern.

This consistent use of rounded corners softens the professional "corporate" aesthetic, making the marketplace feel accessible to community sellers. Highly interactive elements like chips and the Floating Action Button (FAB) use a fully rounded "pill" shape to distinguish them from content containers.

## Components

### Floating Action Button (FAB)
The primary "Sell" action is a prominent circular FAB positioned in the bottom-right. It uses the primary green color with a high-elevation shadow to ensure it remains the most visible element on the screen.

### Product Cards
Cards feature edge-to-edge imagery at the top to highlight product freshness. Content below the image is padded at 12px, including title, price, and location metadata. The card container itself should have a 16px corner radius and a subtle border or very soft shadow.

### Segmented Controls
Used for switching views or categories (e.g., "All," "Vegetables," "Fruits"). These are styled as pill-shaped containers with a subtle background fill for the inactive state and a high-contrast white or primary-colored fill for the active selection.

### Input Fields
Inputs are clear and structural, featuring a 12px corner radius, an 8px internal padding, and a 1px border. The border should shift to the primary green when focused to provide clear visual feedback.

### Chips & Tags
Small labels for status (e.g., "Verified Seller") use a light tonal fill of the primary green with dark green text to signify trust without overwhelming the visual field.